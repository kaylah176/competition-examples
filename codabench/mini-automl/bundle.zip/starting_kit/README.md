# Starting Kit

Welcome to the starting kit! You can put here any useful files and documentation to help the participants diving into the benchmark.

Here, you can find examples submissions: `decision_tree.zip`, `gaussian_nb.zip`, `knn.zip`, `mlp.zip` and `random_forest.zip`.

Good luck!